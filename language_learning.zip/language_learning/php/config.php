<?php
// config.php - Store API Key securely

define('YOUTUBE_API_KEY', ''); // Replace with your actual API key
?>
